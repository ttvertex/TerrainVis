@tengel 
April 24th 2015
glew: 1.12
glfw: 3.1.1
glm: 0.9.6.3
freeimage: 3.17.0
******The libraries are being set on the win32 versions!!!